# Parsely-Conditions

A jQuery plugin that adds conditional logic to the [Parsely.js](http://parsleyjs.org) form validation library

## Documentation
For a complete description of plugin options, instructions and demos [visit the plugin homepage](http://themonk.github.io/parsely-conditions).

## License
Released under MIT license, see LICENSE for details.

